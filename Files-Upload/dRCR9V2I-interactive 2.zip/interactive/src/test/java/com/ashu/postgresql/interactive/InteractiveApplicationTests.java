package com.ashu.postgresql.interactive;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InteractiveApplicationTests {

	@Test
	void contextLoads() {
	}

}
