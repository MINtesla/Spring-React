package com.ashu.postgresql.interactive;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InteractiveApplication {

	public static void main(String[] args) {
		SpringApplication.run(InteractiveApplication.class, args);
	}

}
