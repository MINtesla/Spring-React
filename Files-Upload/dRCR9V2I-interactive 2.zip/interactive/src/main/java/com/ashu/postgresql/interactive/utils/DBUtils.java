package com.ashu.postgresql.interactive.utils;

import org.apache.commons.dbcp2.BasicDataSource;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

// psql "sslmode=verify-ca sslrootcert=server-ca.pem sslcert=client-cert.pem
// sslkey=client-key.pem hostaddr=35.200.237.83 port=5432 user=postgres dbname=postgres"
@Component
public class DBUtils {
    private static BasicDataSource dataSource;

    public static void initbasicDataSource(){
        try{
            dataSource = new BasicDataSource();
            dataSource.setDriverClassName("org.postgresql.Driver");
            dataSource.setUrl("jdbc:postgresql://35.200.237.83:5432/postgres");
            dataSource.setUsername("postgres");
            dataSource.setPassword("Ashutosh@15");
            dataSource.addConnectionProperty("sslmode","verify-ca");
            dataSource.addConnectionProperty("sslrootcert","/Users/ashutoshsingh/pgdb_gcp/server-ca.pem");
            dataSource.addConnectionProperty("sslcert","/Users/ashutoshsingh/pgdb_gcp/client-cert.pem");
            dataSource.addConnectionProperty("sslkey","/Users/ashutoshsingh/pgdb_gcp/client-key.pk8");
            try (Connection c = dataSource.getConnection(); Statement stmt = c.createStatement()) {
                // Turn off auto-commit
                c.setAutoCommit(false);

                System.out.println("Opened database successfully");

                // Execute query
                String s = "";
                ResultSet rs = stmt.executeQuery("select * from \"ECMP_T_INCOMING_LOG\" etil ;");

                while (rs.next()) {
                    // Process the result set
                    System.out.println(rs.getString(2)); // Example processing
                }

                // Commit the transaction
                c.commit();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }catch(Exception e){

        }
    }

    public static DataSource getDataSource(){
        return dataSource;
    }
}
