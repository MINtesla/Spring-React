package com.ashu.postgresql.interactive.service;

import com.ashu.postgresql.interactive.utils.DBUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class InteractiveService {

    @Autowired
    DBUtils dbUtils;

    public void connectToDb(){
        dbUtils.initbasicDataSource();
    }
}
